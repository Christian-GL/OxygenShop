
const dom = new DomHandler('pruebasJS')

const fapi = new APIPersons(dom)






// const chris = new Persona('Christian', 'Gil')
// const hector = new Panadero('Pantheon', 'Noxus')
// console.log(chris)
// console.log(hector)



/*
Shift + Alt + F     --> Formatear código
Ctrl + K + C        --> Comentar código
Ctrl + K + U        --> Descomentar código
 */